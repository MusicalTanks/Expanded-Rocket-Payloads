﻿This work is an original production I scraped together from tutorials and looking at other mods to figure out how they worked, this includes SpaceX, Orbital Ion Cannon, Aidiakapi QOL research, Drone Swarm, Bob’s mods, Deep Mines, Useful Space Industry, Donny’s Fargodeep Mine and Factorio’s base game files (and probably other mods I have forgotten). 

Some elements of this mod do touch on areas other mods have attempted, namely asteroid mining and space power generation. I tried to make my mod work in different ways, for example orbital power generation in Dyson swarm and Useful Space Industry both are based off a script that counts each satellite launch and adds the total to a single ground receiving station. 

I made my mod without using such scripts, you launch a solar power satellite and you get one receiver station per satellite which generates power from that satellite. One reason I wanted to include these was for the completeness of the mod, also dyson swarm mod hasn’t been updated in several months and is a bit unbalanced in my opinion, and useful space industry hasn’t been updated in more than a year. 

I included asteroid mining because the asteroid mining mod hasn’t been updated for 0.16 and I wanted to use a reusable shuttle for it and to give players a way to generate resources late game without having to go crazy with outposts.

Thanks to /u/ulyssessword on reddit for the idea that helped make this possible! When I started out I was lost trying to code the rocket launch to directly buff laboratory productivity (which I don't think is even possible), Ulyssess suggested the space-lab launch produce a byproduct that could be used in research which would allow the productivity bonus. This idea ended up being the basis for many of the mod’s features and saved me a lot of grief.

Some of the graphics in this mod were made by Richard at historicspacecraft.com. With his permission I used and modified them for their roles in the mod. These include the capsule used for station data, and the copper/iron dropships, all the shuttle variants (based off dreamchaser), as well as the space lab component item. All from the International Space Station visiting vehicles image. Thanks Richard!

The Ground Telescope entity is based on a concept image for the Thirty Meter Telescope was modified by me for this project, found on Wikipedia. They request attribution so here it is: Courtesy of the TMT Observatory Corporation. 

All other images are edited versions from the public domain (NASA mostly) or from Factorio’s base game graphics, or combinations of the two. 

Changelog:


0.1.0 
-Added Space Lab


0.2.0
-Added Advanced Probe
-Changed Space Science stack size to 10,000 to accommodate advanced probe
-rebuilt prototype directory


0.2.5
-Added Observation Satellite
-Added Spy Satellite
-Added Planetary Data
-Added repeatable techs: Observation satellite, Orbital Prospecting, Spy Satellite, Orbital Artillery Rangefinding, 


0.3.0
-Added techs: Drone GPS research, advanced battery research, advanced fan research, space telescope research, extremely advanced material processing
-Moved observations satellite, advanced satellite and spy satellite to be dependant on extremely advanced material processing.
-Space lab recipe rebalanced
-Space lab tech now dependant on extremely advanced material processing


0.4.0
-Added Solar collector tech
-Added Solar collector satellite
-Added solar receiver entity


0.4.5
-graphics cleaned up on items
-created new item tab for Mod in the player’s recipe GUI to keep things sane


0.5
-satellite intermediates added
-space-power fixed, no longer on same priority as solar power so it actually works at night
-Added reusable Space Shuttle and new tech to proceed it and orbital power production 


0.5.5 
-changed new infinite techs around to scale up cost after 10-20-30 iterations, etc.
-lowered the cost of shuttle tech from 200k to 100k science packs
-Shuttle Refurbishment building now works even if it does look like crap


0.6.0
-Lowered shuttle construction and refurbishment cost by 1 space-lab payload to ensure viability over space lab payload
-added ground telescope
-ground telescope passively produces space science at the rate of 1 per minute
-renamed spy telescope to space telescope


0.6.5
-space telescope launch now produces space telescope uplink data
-uplink data can be processed for 10 orbital data and a space telescope uplink station
-uplink station produces space science passively at x5 the rate of ground telescopes
-buffed Observation Satellite rocket result from 1 orbital science to 5.


0.7.0
-Advanced probe rocket result changed from 10k space science to x5 probe data
-Probe data can be processed into 2k space science each
-Space science stack size returned to 2k from 10k


0.7.5
-Added Advanced Assembler
-Changed all satellite recipes to be exclusively produced in Advanced Assembler
-change satellite data to be processed exclusively in advanced assembler
-set up advanced assembler in its own tech prior to satellite intermediates
-shuttle production and refurbishment now done exclusively in advanced assembler




0.8.0
-Added Asteroid mining
    -Iron and copper ore dropships
    -Space mining drones that are part of the construction of a new space shuttle class, the mining shuttle.        
    -When refurbished the landed mining shuttle will call down 4000 copper and iron drop pods, each can be opened up by an assembler and 50 iron ore or 50 copper ore will be the result. That means one launch of the mining shuttle will produce 200k worth of Iron and Copper. And since the shuttle is reuseable it should more than make up for assembly and launch costs quickly. 


0.8.5
-Halved solar panel cost and power production of orbital power satellites
-fixed collision box of advanced assembler
-massively rebuild intermediate product recipes to make them less tedious, more challenging. 


0.8.7
-Removed Shuttle refurbishment building from tech unlock so the entity is now hidden.
-Added production science pack to mod techs (doh!)
-scaled up infinite researches cost more
-lowered Spy satellite recipe cost 5 telescope components to 1. 
-space shuttle refurbishment recipe time lengthened from 480 seconds to 800 (this is what made the IRL shuttle program so expensive btw)
-split space shuttle into normal space station shuttle and spy satellite version
-fixed error in space-lab research tech
-scaled advanced bot battery research further


0.8.8
-Mining time for Advanced Assembler reduced from 5 to 2 seconds
-further scaled infinite techs
-added stone to shuttle refurbishment recipes to allow for heat shield repair
-removed solar panels from autonomous mining drone icon, replaced them with stack inserters.
-lowered orbital solar panels cost, power switches from 10 to 1
-lowered ground telescope research cost from 10k to 4k
-lowered space-lab research cost from 10k to 5k
-lowered advanced probe cost from 10k to 6k
-increased mining shuttle’s refurbishment cost rocket fuel 1.5k to 2k to accommodate fully refueling the drones
-added new tech to precede space mining, it unlocks the space mining drones at a relatively cheap research cost to give the player a head start on their production before the mining tech. Also because I wanted to justify using RTGs instead of solar panels on the drones.
-Reduced Space Mining tech cost from 120k to 100k to allow for the loss of Asteroid mining drones to the new preceding tech


0.9.0
-Added non-rotatable flag to advanced assembler entity https://forums.factorio.com/viewtopic.php?f=25&t=62354
-moved iron and copper dropship processing recipe into the space mining sub category
-reduced iron/copper dropship unboxing recipe time from 30 to 3 seconds. 
-increased research time required for Orbital prospecting from 120 to 240
-autofabricator techs, items, entity, recipes added
-lowered research times on all auto fabricator techs


0.9.5
-Fixed Fabricator tech to include shuttle recipe and refurbishment recipe
-reduced sat flight computer cost per fabricator component from 500 to 250
-scaled mining prospecting tech every 25 iterations up to 100
-Added text warning to launch the orbital fabricator component on the Shuttle (doh!)
-lowered orbital fabricator component recipe cost: Advanced Assembler 250 to 100
-fixed several errors with the fabricator shuttle refurbishment recipe
-quintupled the science output of Ground telescope and space telescope uplink stations. 
-fixed Auto Fabricators to work as intended (again thank god for playtesting)
-I want to note the second test of what is probably the most brokenly overpowered building in Factorio was a success, my factory went from producing 25k worth of steel per minute to 160k. Even without speed buffs it should produce 30k stacks of iron, copper, steel or stone, 15k of uranium ore.


0.9.9
-added stack inserter improvement infinite research
-added fabricator shuttle repurposing tech
-artillery rangefinding tech improved from 2% bonus to 5%
-changed shuttle repurposing tech to return satellite thruster units, moved thruster units installation from shuttle hull to finished shuttle products.
-Added new recipe to space telescope uplink station to slowly produce planetary data (1 every 2 minutes).
-removed 10 planetary data from space telescope data processing recipe, with the planetary observation recipe added hopefully this makes space telescopes an interesting alternative to advanced probes/observation satellites/spy shuttles to slowly passively provide both space science and planetary data.
-added new liner scaling code to infinite techs so the cost should increase by 1 unit per level
-returned assembler mk3 max ingredient count back to normal ingredient count
-change prerequisite of space telescope research to space telescopes (duh)
-added description to space telescope tech, artillery rangefinding, orbital prospecting and space telescope research 
-added new techs to simulate construction of advanced orbital facilities. They are extremely expensive but also provide many powerful buffs. Idea being it gives you a kind of ultra-late game goal and use for space lab/shuttle outside of mining or early infinite tech unlocks.
-added satellite flight computer to space lab payload recipe
-new graphic made for orbital AI lab
-stack inserter bonus added to AI lab tech
-reduced the copper output of mining shuttle by half since it was way out of balance. Is now a ratio of 2 iron to 1 copper instead of 1-1. I may need to make it 3-1 but it should be good for now.
-changed around the space telescope uplink recipes to work a bit better


0.16.01 pre-release version
-Renamed mod to expanded rocket payloads version 0.16.1 
-Fixed the category tech not being renamed (you have no idea how long I spent trying to figure out which file was holding up the mod)
-Lowered space telescope uplink power consumption to 5 MW from 10 MW
-Lowered ground telescope power consumption to 1 MW from 10 MW
-removed telescope components from extremely advanced material processing since they were supposed to be under ground telescope
-lowered the costs of the space-lab recipe to compensate for the addition of satellite flight computers to the payload component
-increased cost of shuttle refurbishment for station and spy shuttle back to 1,000
-increased cost of vacuum smelting research from 200 station science to 1000.
-rewrote quite a few of the tech descriptions to make them less repetitive and more informative
-rearranged how the space shuttle recipe category was organized so it looks sane.

0.16.1 initial release
-Changed power output priority of power receiving station from secondary to primary output which should mean it is used before nuclear. 
-changed the space-telescope to directly supply its uplink station like the orbital power receiver to make things a bit less complicated. Removed space telescope uplink data and recipe for uplink station
-fixed massively broken telescope component recipe (4000->100 low density structures, 800 rocket control units to 10 satellite flight computers). Shaved off 19k steel, your welcome.
-telescope components cost of space telescope increased from 1 to 3 to make it much more costly than ground telescope while still being more efficient. 
-completely removed shuttle refurbishment building files
-fixed space telescope to provide space telescope uplink station not orbital power receiver. (oops)
-increased Space Telescope recipe costs all across the board as indirect buff cost effectiveness of Observation Satellite
-fixed ground telescopes and space telescopes only giving out 1 space science per cycle, should correctly be 5 and 25 per min.
-rescaled infinite techs for the umpteenth time:. Cleaned them up so tech screen would be a bit neater. 
-added productivity as possible module effect for advanced assembler, it won’t have any bearing on satellite stuff but could be used to have higher productivity on all other products produced in assemblers, 20% more than normal assemblers which could lead to some fun math in addition to better base crafting speed. Balanced by the fact that advanced assemblers are extremely expensive in comparison. 
-doubled time cost of repurposing space shuttles
-changed ordering value for station science and planetary data so they appear last in the tech window. (this actually delayed release by several days)
-changed tech graphics for several techs to ensure they were copyright free, either derived from Factorio stuff or from public domain images, or combinations of both.
-edited the Space Fabricator’s tech graphic to be a bit more original
-increased the idle power drain of the auto fabricator ground station to 100 MW, because these things weren’t expesnive enough ;) 
-fixed ground auto fabricator station entity to use its own icon and not rely on its advanced assembler daddy. 
-speaking of which: locked the ground auto fabricator station recipe into satellite crafting so only advanced assemblers can make it. 
-change the name of the spy shuttle to Telescope Shuttle to make it less implicitly militaristic
-change name of Planetary data to Telescope data
-changed name of Station Science to Station data
-added new tech image for Telescope Shuttle based off one of the public domain images of STS-103 Hubble Servicing Mission. 
-changed shuttle refurbishment and repurposing recipe names from Spy-shuttle to telescope shuttle
-changed space lab tech image from International Space station to Skylab 
-changed space lab item icon to transparent background skylab
-edited some item/techs/recipe descriptions to accommodate all these name changes
-removed space lab as a prerequisite for advanced space lab, looks better in the tech tree. 
-changed the image for advanced space lab to have a transparent background, did this while watching Spacex talk about their updates to BFR and Moon Tourist. 
-doubled satellite bus cost for autonomous fabricator component from 100 to 200.
-doubled space telescope space science output from 25-50 per minute
-removed the code that moved the base satellite into the mod’s recipe tab
-changed shuttle refurbishment recipe stone cost to 500 for normal shuttle, 1000 for telescope, 2000 for mining and 5000 for fabricator shuttle to simulate their different re-entry heating profiles. 
-added plastic as an ingredient for space shuttle hull: 10,000 units required. 
-increased orbital AI core tech cost from 2,000 to 2,500
-increased research time for extremely advanced rocket payloads from 60 seconds per data to 600
-checked rest of tech images to make sure they were from public domain, changed out a couple. Thank god for wikipedia commons. 
-added new item graphic for orbital fabricator ground component
-replaced tech graphics for space fabricator and space smelting
-massively overhauled item and entity graphics from the development WiP graphics to public domain sourced images. 
-lowered cost of space-lab from 4 satellite engines to 2.
-increased observation satellite engine cost from 1 to 3
-set default request amount for thrusters since their stack size is so high (because shuttle refurbishment stuff)
-doubled time cost of planetary data research at space telescope station
-increased cost of observation satellite
-halved solar panel cost of shuttle hull, increased satellite bus cost. 
-publically released

0.16.2
-changed name of advanced probe graphic to ensure all letters were lowercase

0.16.3
-fixed many spelling errors in the locale file.
-changed around some descriptions to make more sense.


