data:extend({
    {
        type = "recipe",
        name = "iron-dropship-unboxing",
        category = "satellite-crafting",
        energy_required = 5,
        enabled = "false",
        ingredients = 
        {
            {"iron-dropship", 1},
          },
        result = "iron-ore",
        result_count = 50,
        subgroup = "space-mining",
    }
})