data:extend({
    {
        type = "item",
        name = "space-lab",
        icon = "__expanded-rocket-payloads__/graphic/skylab-32.png",
        icon_size = 32,
        flags = {"goes-to-quickbar"},
        subgroup = "satellites",
        order = "mSS",
        stack_size = 1,
        rocket_launch_product = {"station-science", 1},
    }
})