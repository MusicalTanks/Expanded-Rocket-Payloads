data:extend({
    {
      type = "item",
      name = "telescope-components",
      icon = "__expanded-rocket-payloads__/graphic/telescope-components.png",
      icon_size = 32,
      flags = {"goes-to-main-inventory"},
      subgroup = "satellite-intermediaries",
      order = "m",
      stack_size = 10
    }
})