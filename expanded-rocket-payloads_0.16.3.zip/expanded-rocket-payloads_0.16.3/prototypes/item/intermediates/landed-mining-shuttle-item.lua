data:extend({
    {
        type = "item",
        name = "landed-mining-shuttle",
        icon = "__expanded-rocket-payloads__/graphic/landed-mining-shuttle-32.png",
        icon_size = 32,
        flags = {"goes-to-quickbar"},
        subgroup = "space-mining",
        order = "mS",
        stack_size = 1,
    }
})