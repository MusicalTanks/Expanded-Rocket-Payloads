data:extend({
    {
        type = "item",
        name = "shuttle-hull",
        icon = "__expanded-rocket-payloads__/graphic/dreamchaser-hull-32.png",
        icon_size = 32,
        flags = {"goes-to-quickbar"},
        subgroup = "shuttle",
        order = "mS",
        stack_size = 1,
    }
})