data:extend({
    {
      type = "item",
      name = "copper-dropship",
      icon = "__expanded-rocket-payloads__/graphic/copper-dropship-32.png",
      icon_size = 32,
      flags = {"goes-to-main-inventory"},
      subgroup = "space-mining",
      order = "n",
      stack_size = 4000
    }
})