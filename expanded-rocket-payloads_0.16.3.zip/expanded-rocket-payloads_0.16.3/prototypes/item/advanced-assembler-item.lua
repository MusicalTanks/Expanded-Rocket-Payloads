data:extend({
    {
        type = "item",
        name = "advanced-assembler",
        icon = "__expanded-rocket-payloads__/graphic/advanced-assembler-32.png",
        icon_size = 32,
        flags = {"goes-to-quickbar"},
        subgroup = "buildings",
        order = "mS",
        stack_size = 1,
        place_result = "advanced-assembler",
    }
})